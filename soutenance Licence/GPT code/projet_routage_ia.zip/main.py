
import os
import time

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def wait():
    input("\n🔁 Appuie sur Entrée pour revenir au menu...")

def menu():
    while True:
        clear()
        print("╔════════════════════════════════════╗")
        print("║   🧠 ROUTAGE INTELLIGENT - MENU    ║")
        print("╠════════════════════════════════════╣")
        print("║ 1. Collecter les métriques         ║")
        print("║ 2. Entraîner le modèle IA          ║")
        print("║ 3. Visualiser le chemin optimal    ║")
        print("║ 4. Lancer la simulation complète   ║")
        print("║ 5. Quitter                         ║")
        print("╚════════════════════════════════════╝")
        choix = input("👉 Choix : ")

        if choix == "1":
            print("\n📊 Lancement de la collecte de métriques...")
            os.system("python3 metriques.py")
            wait()
        elif choix == "2":
            print("\n🎓 Entraînement du modèle IA (Q-Learning)...")
            os.system("python3 train.py")
            wait()
        elif choix == "3":
            print("\n📡 Visualisation graphique du chemin choisi...")
            os.system("python3 visualisation.py")
            wait()
        elif choix == "4":
            print("\n🚀 Simulation complète : collecte + entraînement + visualisation")
            os.system("python3 metriques.py")
            time.sleep(2)
            os.system("python3 train.py")
            time.sleep(2)
            os.system("python3 visualisation.py")
            wait()
        elif choix == "5":
            print("\n👋 Au revoir !")
            break
        else:
            print("\n❌ Choix invalide.")
            time.sleep(1)

if __name__ == "__main__":
    menu()
